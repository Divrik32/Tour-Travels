// import React from "react";
// import { Star } from "lucide-react";
// import { motion } from "framer-motion";

// const testimonials = [
//     {
//         name: "Andrew Simon",
//         role: "Traveller",
//         avatar: "/testimonial-andrew.png",
//         rating: 5,
//         quote:
//             "A home that perfectly blends sustainability with luxury until I discovered Ecoland Residence. From the moment I stepped into this community, I knew it was where I wanted to live. The commitment to eco-friendly living",
//     },
//     {
//         name: "Maria Doe",
//         role: "Traveller",
//         avatar: "/placeholder.svg",
//         rating: 5,
//         quote:
//             "A home that perfectly blends sustainability with luxury until I discovered Ecoland Residence. From the moment I stepped into this community, I knew it was where I wanted to live. The commitment to eco-friendly living",
//     },
//     {
//         name: "Michel Smith",
//         role: "Traveller",
//         avatar: "/testimonial-michel.png",
//         rating: 5,
//         quote:
//             "A home that perfectly blends sustainability with luxury until I discovered Ecoland Residence. From the moment I stepped into this community, I knew it was where I wanted to live. The commitment to eco-friendly living",
//     },
// ];

// export default function Testimonials() {
//     const cardVariants = {
//         hidden: { opacity: 0, y: 50 },
//         visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
//     };

//     const getInitials = (name) =>
//         name
//             .split(" ")
//             .map((n) => n[0])
//             .join("");

//     return (
//         <section className="py-20 bg-gray-50">
//             <div className="max-w-6xl mx-auto px-4 text-center">
//                 <motion.p
//                     initial={{ opacity: 0, y: 20 }}
//                     whileInView={{ opacity: 1, y: 0 }}
//                     viewport={{ once: true }}
//                     transition={{ duration: 0.5 }}
//                     className="text-lg font-serif italic text-gray-500"
//                 >
//                     Testimonial
//                 </motion.p>
//                 <motion.h2
//                     initial={{ opacity: 0, y: 20 }}
//                     whileInView={{ opacity: 1, y: 0 }}
//                     viewport={{ once: true }}
//                     transition={{ delay: 0.2, duration: 0.5 }}
//                     className="text-4xl md:text-5xl font-bold text-gray-800 mb-12"
//                 >
//                     What Client Say About Us
//                 </motion.h2>

//                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
//                     {testimonials.map((testimonial, index) => (
//                         <motion.div
//                             key={testimonial.name}
//                             variants={cardVariants}
//                             initial="hidden"
//                             whileInView="visible"
//                             viewport={{ once: true, amount: 0.3 }}
//                             transition={{ delay: index * 0.1 }}
//                         >
//                             <div className="p-6 flex flex-col items-center text-center rounded-xl shadow-lg bg-white h-full relative">
//                                 <div className="flex items-center mb-4">
//                                     <div className="w-16 h-16 rounded-full overflow-hidden mr-4 border border-gray-300">
//                                         {testimonial.avatar ? (
//                                             <img
//                                                 src={testimonial.avatar}
//                                                 alt={testimonial.name}
//                                                 className="w-full h-full object-cover"
//                                             />
//                                         ) : (
//                                             <div className="w-full h-full flex items-center justify-center bg-gray-200 text-gray-600 font-bold text-xl">
//                                                 {getInitials(testimonial.name)}
//                                             </div>
//                                         )}
//                                     </div>
//                                     <div className="text-left">
//                                         <h3 className="text-lg font-semibold text-gray-800">{testimonial.name}</h3>
//                                         <p className="text-sm text-gray-500">{testimonial.role}</p>
//                                         <div className="flex items-center mt-1">
//                                             {[...Array(5)].map((_, i) => (
//                                                 <Star
//                                                     key={i}
//                                                     className={`h-4 w-4 ${i < testimonial.rating
//                                                             ? "fill-yellow-400 text-yellow-400"
//                                                             : "text-gray-300"
//                                                         }`}
//                                                 />
//                                             ))}
//                                         </div>
//                                     </div>
//                                 </div>
//                                 <p className="text-gray-500 text-sm italic mb-4">
//                                     &quot;{testimonial.quote}&quot;
//                                 </p>
//                                 <div className="absolute bottom-4 right-4 text-blue-600 text-5xl font-bold opacity-20">
//                                     99
//                                 </div>
//                             </div>
//                         </motion.div>
//                     ))}
//                 </div>
//             </div>
//         </section>
//     );
// }


// import React, { useEffect, useState } from "react";

// export default function Testimonials() {
//     const [testimonials, setTestimonials] = useState([]);

//     useEffect(() => {
//         const fetchTestimonials = async () => {
//             try {
//                 const res = await fetch("http://localhost:5000/api/testimonials");
//                 const data = await res.json();
//                 setTestimonials(data);
//             } catch (err) {
//                 console.error("Error loading testimonials", err);
//             }
//         };
//         fetchTestimonials();
//     }, []);

//     return (
//         <section className="bg-gray-100 py-10 px-4">
//             <div className="max-w-6xl mx-auto text-center">
//                 <h2 className="text-3xl font-bold mb-6">What Our Travelers Say</h2>
//                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
//                     {testimonials.map((t) => (
//                         <div
//                             key={t._id}
//                             className="bg-white p-6 rounded-lg shadow hover:shadow-md transition"
//                         >
//                             <p className="text-gray-700 mb-4">"{t.message}"</p>
//                             <div className="text-yellow-400 text-lg mb-2">
//                                 {Array.from({ length: t.rating }, (_, i) => (
//                                     <span key={i}>★</span>
//                                 ))}
//                                 {Array.from({ length: 5 - t.rating }, (_, i) => (
//                                     <span key={i} className="text-gray-300">★</span>
//                                 ))}
//                             </div>
//                             <p className="font-semibold text-gray-800">— {t.name}</p>
//                         </div>
//                     ))}
//                 </div>
//             </div>
//         </section>
//     );
// }


// import React, { useEffect, useState } from "react";

// export default function Testimonials() {
//     const [testimonials, setTestimonials] = useState([]);

//     useEffect(() => {
//         const fetchTestimonials = async () => {
//             try {
//                 const res = await fetch("http://localhost:5000/api/testimonials");
//                 const data = await res.json();
//                 setTestimonials(data);
//             } catch (err) {
//                 console.error("Error loading testimonials", err);
//             }
//         };
//         fetchTestimonials();
//     }, []);

//     return (
//         <section className="bg-gray-100 py-10 px-4">
//             <div className="max-w-6xl mx-auto text-center">
//                 <h2 className="text-3xl font-bold mb-8">What Our Travelers Say</h2>
//                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
//                     {testimonials.map((t) => (
//                         <div
//                             key={t._id}
//                             className="bg-white p-6 rounded-lg shadow hover:shadow-md transition flex flex-col items-center text-center"
//                         >
//                             {/* Show user image or fallback */}
//                             <img
//                                 src={t.image || "https://via.placeholder.com/100x100.png?text=User"}
//                                 alt={t.name}
//                                 className="w-20 h-20 rounded-full object-cover mb-4"
//                             />

//                             {/* Message */}
//                             <p className="text-gray-700 mb-4">"{t.message}"</p>

//                             {/* Star Rating */}
//                             <div className="text-yellow-400 text-lg mb-2">
//                                 {Array.from({ length: t.rating }, (_, i) => (
//                                     <span key={i}>★</span>
//                                 ))}
//                                 {Array.from({ length: 5 - t.rating }, (_, i) => (
//                                     <span key={i} className="text-gray-300">★</span>
//                                 ))}
//                             </div>

//                             {/* Name */}
//                             <p className="font-semibold text-gray-800">— {t.name}</p>
//                         </div>
//                     ))}
//                 </div>
//             </div>
//         </section>
//     );
// }



// import React, { useEffect, useState } from "react";

// export default function Testimonials() {
//     const [testimonials, setTestimonials] = useState([]);

//     useEffect(() => {
//         const fetchTestimonials = async () => {
//             try {
//                 const res = await fetch("http://localhost:5000/api/testimonials");
//                 const data = await res.json();
//                 setTestimonials(data);
//             } catch (err) {
//                 console.error("Error loading testimonials", err);
//             }
//         };
//         fetchTestimonials();
//     }, []);

//     return (
//         <section className="bg-gray-100 py-10 px-4">
//             <div className="max-w-6xl mx-auto text-center">
//                 <h2 className="text-3xl font-bold mb-8">What Our Travelers Say</h2>
//                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
//                     {testimonials.map((t) => (
//                         <div
//                             key={t._id}
//                             className="bg-white p-6 rounded-lg shadow hover:shadow-md transition flex flex-col items-center text-center"
//                         >
//                             <img
//                                 src={t.image?.trim() !== "" ? t.image : "https://via.placeholder.com/100x100.png?text=User"}
//                                 alt={t.name}
//                                 className="w-20 h-20 rounded-full object-cover mb-4 border"
//                             />
//                             <p className="text-gray-700 mb-4">"{t.message}"</p>
//                             <div className="text-yellow-400 text-lg mb-2">
//                                 {[...Array(5)].map((_, i) => (
//                                     <span key={i} className={i < t.rating ? "text-yellow-400" : "text-gray-300"}>
//                                         ★
//                                     </span>
//                                 ))}
//                             </div>
//                             <p className="font-semibold text-gray-800">— {t.name}</p>
//                         </div>
//                     ))}
//                 </div>
//             </div>
//         </section>
//     );
// }


import React, { useEffect, useRef, useState } from "react";

export default function Testimonials() {
    const [testimonials, setTestimonials] = useState([]);
    const scrollRef = useRef(null);

    useEffect(() => {
        const fetchTestimonials = async () => {
            try {
                const res = await fetch("http://localhost:5000/api/testimonials");
                const data = await res.json();
                setTestimonials(data);
            } catch (err) {
                console.error("Error loading testimonials", err);
            }
        };
        fetchTestimonials();
    }, []);

    const scrollLeft = () => {
        scrollRef.current.scrollBy({ left: -300, behavior: "smooth" });
    };

    const scrollRight = () => {
        scrollRef.current.scrollBy({ left: 300, behavior: "smooth" });
    };

    return (
        <section className="bg-gray-100 py-10 px-4 relative">
            <div className="max-w-6xl mx-auto text-center">
                <h2 className="text-3xl font-bold mb-8">What Our Travelers Say</h2>

                {/* Scrollable Carousel */}
                <div className="relative">
                    {/* Scroll buttons */}
                    <button
                        onClick={scrollLeft}
                        className="absolute left-0 top-1/2 transform -translate-y-1/2 bg-white shadow rounded-full p-2 z-10"
                    >
                        ◀
                    </button>
                    <button
                        onClick={scrollRight}
                        className="absolute right-0 top-1/2 transform -translate-y-1/2 bg-white shadow rounded-full p-2 z-10"
                    >
                        ▶
                    </button>

                    <div
                        ref={scrollRef}
                        className="flex overflow-x-auto gap-4 px-8 scroll-smooth no-scrollbar"
                    >
                        {testimonials.map((t) => (
                            <div
                                key={t._id}
                                className="min-w-[300px] bg-white p-6 rounded-lg shadow hover:shadow-md transition flex-shrink-0 text-center"
                            >
                                <img
                                    src={
                                        t.image?.trim() !== ""
                                            ? t.image
                                            : "https://via.placeholder.com/100x100.png?text=User"
                                    }
                                    alt={t.name}
                                    className="w-20 h-20 rounded-full object-cover mx-auto mb-4 border"
                                />
                                <p className="text-gray-700 mb-4">"{t.message}"</p>
                                <div className="text-yellow-400 text-lg mb-2">
                                    {[...Array(5)].map((_, i) => (
                                        <span key={i} className={i < t.rating ? "text-yellow-400" : "text-gray-300"}>
                                            ★
                                        </span>
                                    ))}
                                </div>
                                <p className="font-semibold text-gray-800">— {t.name}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </section>
    );
}
