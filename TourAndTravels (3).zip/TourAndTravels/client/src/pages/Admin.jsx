// pages/AdminPanel.jsx
import React, { useEffect, useState } from "react";
import { useAuth } from "../context/authContext";

export default function AdminPanel() {
    const { user } = useAuth();
    const [tours, setTours] = useState([]);

    const fetchTours = async () => {
        const res = await fetch("http://localhost:5000/api/tours");
        const data = await res.json();
        setTours(data);
    };

    const deleteTour = async (id) => {
        const token = localStorage.getItem("token");
        await fetch(`http://localhost:5000/api/tours/${id}`, {
            method: "DELETE",
            headers: { Authorization: `Bearer ${token}` },
        });
        fetchTours();
    };

    useEffect(() => {
        if (user?.role === "admin") {
            fetchTours();
        }
    }, []);

    return (
        <div className="p-4">
            <h2 className="text-xl font-bold mb-4">Admin Panel: Manage Tours</h2>
            <ul className="space-y-2">
                {tours.map((tour) => (
                    <li key={tour._id} className="flex justify-between items-center border p-2">
                        <span>{tour.name}</span>
                        <button onClick={() => deleteTour(tour._id)} className="text-red-600">Delete</button>
                    </li>
                ))}
            </ul>
        </div>
    );
}
