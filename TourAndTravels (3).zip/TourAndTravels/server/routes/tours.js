const express = require("express");
const router = express.Router();
const Tour = require("../models/Tour");
const { verifyToken, isAdmin } = require("../../client/src/context/auth");

// Add Tour
router.post("/", verifyToken, isAdmin, async (req, res) => {
  try {
    const newTour = new Tour(req.body);
    await newTour.save();
    res.status(201).json({ message: "Tour created" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update Tour
router.put("/:id", verifyToken, isAdmin, async (req, res) => {
  try {
    await Tour.findByIdAndUpdate(req.params.id, req.body);
    res.json({ message: "Tour updated" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete Tour
router.delete("/:id", verifyToken, isAdmin, async (req, res) => {
  try {
    await Tour.findByIdAndDelete(req.params.id);
    res.json({ message: "Tour deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
